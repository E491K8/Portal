<?php
include_once ('config.php');

session_start();
    // Update the path below to your autoload.php,
    // see https://getcomposer.org/doc/01-basic-usage.md
    require_once 'vendor/autoload.php';
    use Twilio\Rest\Client;

    $new_sid = $_SESSION['SESSION_NEW_SSID'];
    $new_otp = $_SESSION['SESSION_OTP'];
    $ray_id = mt_rand(000000000, 999999999);

    $sid    = "AC454ca4c07b5965d001d3030460dd49a4";
    $token  = "54719874dae04aaed9fce01d987d1e1d";
    $twilio = new Client($sid, $token);

    $sql = "SELECT * FROM user WHERE ssid='$new_sid'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);

        $number = $row['number'];

    $message = $twilio->messages->create(
        "$number", // to
       [
        'from' => "+15075854140",
        'body' => "Hi, there welcome to newly started NFT Market place powered by XPRESS. Your 2AF Code $new_otp. Login using this OTP with the RAY-ID of $ray_id. XPRESS"
       ]
      );}

      if($message){
        $_SESSION["SESSION_SSID"] = $new_sid;
        header("Location: verification.php");
      } else {
        echo "something went wrong!";
      }

print($message->sid);