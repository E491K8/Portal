<?php

$conn = mysqli_connect("database-1.ctsrely4bvgo.ap-south-1.rds.amazonaws.com", "admin", "pawan2244", "system");

if (!$conn) {
    echo "Connection failed";
}
?>